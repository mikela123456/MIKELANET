
import React, { useState, useEffect } from 'react';
import { User, Sword, Package, Zap, Compass, Truck, Timer, Trophy, Shield, Activity, Clock, ShieldAlert } from 'lucide-react';
import { AdBanner } from './AdBanner';

type GameTab = 'profile' | 'expeditions' | 'items';

export const GameView: React.FC = () => {
  const [activeTab, setActiveTab] = useState<GameTab>('profile');
  const [mikelaReserves, setMikelaReserves] = useState(0);
  const [reputation, setReputation] = useState(1240);
  const [expeditionLevel, setExpeditionLevel] = useState(1);
  const [activeExpedition, setActiveExpedition] = useState<boolean>(false);
  const [progress, setProgress] = useState(0);
  const [timeLeft, setTimeLeft] = useState(0);
  const [adsDestroyed, setAdsDestroyed] = useState(0);

  const startExpedition = () => {
    setActiveExpedition(true);
    setProgress(0);
    setAdsDestroyed(0);
    setTimeLeft(21);
  };

  useEffect(() => {
    if (!activeExpedition || timeLeft <= 0) {
      if (timeLeft === 0 && activeExpedition) {
        setMikelaReserves(p => p + (adsDestroyed * 75));
        setActiveExpedition(false);
      }
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft(prev => prev - 1);
      setProgress(prev => Math.min(100, prev + 5));
    }, 1000);
    return () => clearInterval(timer);
  }, [activeExpedition, timeLeft, adsDestroyed]);

  return (
    <div className="flex h-full w-full bg-[#050010] relative">
      {/* Sidebar */}
      <aside className="w-20 border-r border-[#00f3ff]/10 bg-black/60 flex flex-col items-center py-10 z-20">
        <div className="flex flex-col space-y-12">
          <button onClick={() => setActiveTab('profile')} className={`p-4 ${activeTab === 'profile' ? 'text-[#00f3ff]' : 'text-white/20'}`}><User size={24} /></button>
          <button onClick={() => setActiveTab('expeditions')} className={`p-4 ${activeTab === 'expeditions' ? 'text-[#00f3ff]' : 'text-white/20'}`}><Sword size={24} /></button>
          <button onClick={() => setActiveTab('items')} className={`p-4 ${activeTab === 'items' ? 'text-[#00f3ff]' : 'text-white/20'}`}><Package size={24} /></button>
        </div>
      </aside>

      <main className="flex-1 relative overflow-y-auto pb-32">
        {activeExpedition ? (
          <div className="p-8 flex flex-col items-center h-full">
            {/* Sector Header Box */}
            <div className="w-full max-w-xl border-2 border-[#00f3ff]/40 bg-black/80 p-6 flex justify-between items-center mb-12 shadow-[0_0_20px_rgba(0,243,255,0.1)]">
              <div className="flex items-center gap-4">
                <Activity className="text-[#00f3ff]" size={32} />
                <h3 className="text-2xl font-black text-white italic tracking-widest uppercase">SEKTOR_0X{expeditionLevel}</h3>
              </div>
              <div className="flex items-center gap-4 border-l border-[#00f3ff]/20 pl-6">
                <Clock className="text-[#00f3ff]" size={24} />
                <span className="font-mono text-3xl font-black text-[#00f3ff]">0:{timeLeft < 10 ? '0' : ''}{timeLeft}</span>
              </div>
            </div>

            {/* Battle Zone */}
            <div className="flex-1 flex flex-col items-center justify-center space-y-12">
               <AdBanner onDestroyed={() => setAdsDestroyed(p => p + 1)} playerAtk={1} />
               <div className="p-4 border border-[#00f3ff]/20 bg-black/40 text-center">
                  <p className="text-[10px] text-[#00f3ff] uppercase tracking-[0.3em]">KLIKNĚTE NA BANNER PRO LIKVIDACI</p>
               </div>
            </div>

            {/* Bottom Status Bar */}
            <footer className="fixed bottom-0 left-20 right-0 h-24 bg-black border-t border-[#00f3ff]/30 flex flex-col justify-center px-10">
               <div className="max-w-3xl mx-auto w-full">
                  <div className="flex justify-between text-xs font-black text-[#00f3ff] uppercase tracking-widest mb-2">
                     <span>SYNCHRONIZACE: {progress}%</span>
                     <span>SMAZÁNO: {adsDestroyed}</span>
                  </div>
                  <div className="h-2 bg-white/5 border border-white/10 overflow-hidden">
                     <div className="h-full bg-[#00f3ff] shadow-[0_0_10px_#00f3ff]" style={{ width: `${progress}%` }} />
                  </div>
               </div>
            </footer>
          </div>
        ) : (
          <div className="p-12 max-w-4xl mx-auto">
            {activeTab === 'profile' && (
              <div className="bg-black/40 border border-[#00f3ff]/20 p-10 flex gap-10 items-center">
                <div className="w-32 h-32 border-2 border-[#ff00ff] p-2 bg-black"><div className="w-full h-full bg-white/5" /></div>
                <div>
                  <h2 className="text-5xl font-black text-white italic uppercase tracking-tighter">ADMIN_77</h2>
                  <div className="mt-6 flex gap-6">
                    <div className="bg-white/5 p-4 border border-white/10"><p className="text-[10px] text-gray-500 uppercase">MIKELA</p><p className="text-xl font-black text-[#00f3ff]">{mikelaReserves} MK</p></div>
                    <div className="bg-white/5 p-4 border border-white/10"><p className="text-[10px] text-gray-500 uppercase">REPUTACE</p><p className="text-xl font-black text-white">{reputation}</p></div>
                  </div>
                </div>
              </div>
            )}
            {activeTab === 'expeditions' && (
              <div className="flex justify-center py-20">
                <button onClick={startExpedition} className="px-16 py-8 border-2 border-[#ff00ff] bg-black hover:bg-[#ff00ff]/10 text-[#ff00ff] font-black uppercase tracking-[0.5em] text-xl italic transition-all">VSTOUPIT_DO_SÍTĚ</button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
};
