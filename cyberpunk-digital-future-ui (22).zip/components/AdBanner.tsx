
import React, { useEffect, useState, useRef } from 'react';
import { Zap } from 'lucide-react';

interface AdBannerProps {
  onDestroyed?: () => void;
  playerAtk?: number;
}

export const AdBanner: React.FC<AdBannerProps> = ({ onDestroyed, playerAtk = 1 }) => {
  const [health, setHealth] = useState(100);
  const [isDead, setIsDead] = useState(false);
  const adRef = useRef<HTMLDivElement>(null);

  // Čistá injekce skriptu bez manipulace s window.blur nebo globálními objekty
  useEffect(() => {
    if (!adRef.current || isDead) return;

    const currentAdRef = adRef.current;
    currentAdRef.innerHTML = ''; 

    const confScript = document.createElement('script');
    confScript.type = 'text/javascript';
    confScript.text = `
      atOptions = {
        'key' : 'a85ff9ddbe88616be678af1325d6582c',
        'format' : 'iframe',
        'height' : 50,
        'width' : 320,
        'params' : {}
      };
    `;

    const invokeScript = document.createElement('script');
    invokeScript.type = 'text/javascript';
    invokeScript.src = 'https://www.highperformanceformat.com/a85ff9ddbe88616be678af1325d6582c/invoke.js';
    
    currentAdRef.appendChild(confScript);
    currentAdRef.appendChild(invokeScript);

    return () => {
      currentAdRef.innerHTML = '';
    };
  }, [isDead]);

  const handleManualHit = () => {
    const damage = 34 + (playerAtk * 5);
    setHealth(prev => {
      const next = Math.max(0, prev - damage);
      if (next <= 0) {
        setIsDead(true);
        setTimeout(() => onDestroyed?.(), 500);
      }
      return next;
    });
  };

  if (isDead) {
    return (
      <div className="w-[320px] h-[50px] flex items-center justify-center animate-pulse border border-[#00f3ff]/20 bg-[#00f3ff]/5">
        <Zap className="text-[#00f3ff]" size={24} />
      </div>
    );
  }

  return (
    <div className="relative w-[320px] flex flex-col items-center">
      {/* HP Bar */}
      <div className="w-full h-1.5 bg-black/50 border border-white/10 mb-1 overflow-hidden">
        <div 
          className="h-full bg-[#00f3ff] transition-all duration-300" 
          style={{ width: `${health}%` }}
        />
      </div>

      {/* Klikatelná oblast nad bannerem pro simulaci boje (pokud blur nefunguje) */}
      <div className="relative w-[320px] h-[50px] cursor-crosshair group">
        <div 
          ref={adRef} 
          className="absolute inset-0 z-10"
        />
        {/* Průhledná vrstva pro zachycení kliku bez blokování reklamy */}
        <div 
          onClick={handleManualHit}
          className="absolute inset-0 z-20 hover:bg-white/5 transition-colors"
        />
      </div>
    </div>
  );
};
