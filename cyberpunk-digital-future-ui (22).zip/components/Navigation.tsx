
import React from 'react';

interface NavigationProps {
  onLogout: () => void;
}

export const Navigation: React.FC<NavigationProps> = ({ onLogout }) => {
  return (
    <nav className="fixed top-0 left-0 w-full h-20 bg-black/90 backdrop-blur-md flex items-center justify-between px-8 z-[100] border-b border-[#00f3ff]/30">
      {/* Levá část: Dashboard */}
      <div className="flex flex-col items-start min-w-[140px]">
        <span className="text-[#00f3ff] font-black tracking-[0.2em] uppercase text-xl italic">
          DASHBOARD
        </span>
        <div className="w-full h-1 bg-[#00f3ff] shadow-[0_0_10px_#00f3ff] mt-1" />
      </div>
      
      {/* Střední část: User ID */}
      <div className="flex flex-col items-center">
        <span className="text-[10px] text-[#00f3ff]/50 uppercase tracking-[0.3em] font-bold">USER_IDENT</span>
        <span className="text-lg text-white font-black uppercase tracking-widest italic">ADMIN_77</span>
      </div>

      {/* Pravá část: Odhlásit */}
      <div className="min-w-[140px] flex justify-end">
        <button 
          onClick={onLogout}
          className="px-6 py-2 border-2 border-[#ff00ff] text-[#ff00ff] text-[12px] uppercase font-black hover:bg-[#ff00ff] hover:text-black transition-all active:scale-95 shadow-[0_0_15px_rgba(255,0,255,0.2)]"
        >
          ODHLÁSIT
        </button>
      </div>
    </nav>
  );
};
